#!/bin/bash

# build and install SGX driver

git clone https://github.com/intel/linux-sgx-driver.git

pushd linux-sgx-driver
git checkout 0373e2e8b96d9a261657b7657cb514f003f67094
make
sudo mkdir -p "/lib/modules/"`uname -r`"/kernel/drivers/intel/sgx"    
sudo cp isgx.ko "/lib/modules/"`uname -r`"/kernel/drivers/intel/sgx"    
sudo sh -c "cat /etc/modules | grep -Fxq isgx || echo isgx >> /etc/modules"    
sudo /sbin/depmod
sudo /sbin/modprobe isgx
popd

# build and install SGX SDK

git clone https://github.com/intel/linux-sgx.git
git -C linux-sgx checkout 73b8b57aea306d1633cc44a2efc40de6f4217364

make -C linux-sgx preparation

subdir_name=$(lsb_release -is | tr '[:upper:]' '[:lower:]')$(lsb_release -rs)
sudo cp linux-sgx/external/toolset/$subdir_name/* /usr/local/bin

make -C linux-sgx sdk DEBUG=1
make -C linux-sgx sdk_install_pkg DEBUG=1

sudo linux-sgx/linux/installer/bin/sgx_linux_x64_sdk_2.13.100.4.bin << EOF
no
/opt/intel
EOF

# build and install SGX PSW

make -C linux-sgx psw DEBUG=1

sudo linux-sgx/linux/installer/bin/sgx_linux_x64_psw_2.13.100.4.bin

# build and install OpenEnclave SDK


git clone https://github.com/openenclave/openenclave.git 
git -C openenclave checkout 21106a984a462b05c672b91995dba55c33727d3d
git -C openenclave submodule update --init --recursive

patch -d openenclave -p0 < openenclave.patch

sudo openenclave/scripts/ansible/install-ansible.sh
ansible-playbook openenclave/scripts/ansible/oe-contributors-setup.yml
mkdir openenclave/build

pushd openenclave/build
cmake .. -DBUILD_TESTS=off && make
cmake .. -DCMAKE_INSTALL_PREFIX=../install && make install
popd

# Prepare environment variables for work

cat > ./source.sh << EOF
export SGX_DRIVER_DIR=$(pwd)/linux-sgx-driver
export SMASHEX_SINGLE_STEP_INCLUDE=$(pwd)/single-stepping/apic_timer/lib
export OE_HOME=$(pwd)/openenclave/install
export OEBIN=$(pwd)/openenclave/install/bin
export MBEDTLS_INCLUDE=$(pwd)/cases/mbedtls/include
export MBEDTLS_LIBRARY=$(pwd)/cases/mbedtls/build/library
source /opt/intel/sgxsdk/environment
source $(pwd)/openenclave/install/share/openenclave/openenclaverc
EOF

source source.sh

# Build driver and library for configuring APIC timer

make -C single-stepping/apic_timer/driver
make -C single-stepping/apic_timer/lib

# Fetch files for curl
mkdir cases
git clone https://github.com/openenclave/openenclave-curl.git cases/curl
git -C cases/curl checkout d9b9171f24f905a0c8194b1c80cbb542eb25427e
git -C cases/curl submodule update --init --recursive
patch -d cases/curl -p0 < curl.patch

echo "To start working: source source.sh && ./scripts/prepare.sh"

