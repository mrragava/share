## SmashEx Proof-of-Concept

### NOTE
* There is a risk of freezing your kernel. Please do not try on a production system.
* We use Ubuntu 18.04 LTS, which is the only GNU/Linux distribution officially supported by OpenEnclave according to its documentation.

### PREREQUISITES

#### Hardware
SGXv1 + FLC support
#### Operating System
Ubuntu 18.04 LTS

#### Software Packages

```
build-essential ocaml ocamlbuild automake autoconf libtool wget
python libssl-dev git cmake perl libssl-dev libcurl4-openssl-dev
protobuf-compiler libprotobuf-dev debhelper cmake reprepro unzip
```

### INSTALLATION

#### Kernel Parameters

We need to specify a few kernel parameters in order to configure the APIC timer in user space. This is done by configuring GRUB to pass those parameters when booting the kernel. 

1. Edit `/etc/default/grub`, set ``GRUB_CMDLINE_LINUX_DEFAULT``  to ``"quiet splash nox2apic iomem=relaxed no_timer_check nosmep nosmap clearcpuid=514 isolcpus=1 nmi_watchdog=0"``
2. Update GRUB configuration with ``sudo update-grub``
3. Reboot

#### SGX Software

To build and set up Intel SGX driver/PSW, Microsoft OpenEnclave as well as the library/driver used in the exploits, run the ``install.sh`` script.

```
./install.sh
```

### Examples

Before trying the examples, you need to import several environment variables and install the driver that is used in the exploits.

```
source source.sh
scripts/prepare.sh
```

#### Hello World

##### Build

```
mkdir attack/build
cd attack/build
cmake ..
make
```

##### Run

```
cd attack/build
make run-su
```

#### OpenEnclave-cURL

##### Build

```
cd cases/curl
mkdir build && cd build
cmake ..
make
```

##### Run

```
cd cases/curl/tests-prefix/src/tests-build
sudo host/tests.host enclave/tests.enclave.signed
```

### Credits

Part of the exploit code is based on SGX-Step (https://github.com/jovanbulck/sgx-step) by Jo Van Bulck.