#!/bin/bash

CURDIR=$(dirname $(readlink -f $0))

source "$CURDIR"/../source.sh
make -C "$CURDIR"/../single-stepping/apic_timer/driver/ load
echo 0 | sudo tee /proc/sys/kernel/randomize_va_space > /dev/null

